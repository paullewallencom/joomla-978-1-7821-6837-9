<?php
defined('_JEXEC') or die;

class FolioControllerFolio extends JControllerForm
{
}