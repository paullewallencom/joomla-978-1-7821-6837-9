ALTER TABLE `#__folio` ADD `metakey` text NOT NULL;
ALTER TABLE `#__folio` ADD `metadesc` text NOT NULL;
ALTER TABLE `#__folio` ADD `metadata` text NOT NULL;
ALTER TABLE `#__folio` ADD `params` text NOT NULL;