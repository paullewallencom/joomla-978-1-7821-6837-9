ALTER TABLE [#__folio] ADD [metakey] [nvarchar](max) NOT NULL;
ALTER TABLE [#__folio] ADD [metadesc] [nvarchar](max) NOT NULL;
ALTER TABLE [#__folio] ADD [metadata] [nvarchar](max) NOT NULL;
ALTER TABLE [#__folio] ADD [params] [nvarchar](max) NOT NULL;