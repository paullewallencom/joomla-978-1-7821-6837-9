<?php
defined('_JEXEC') or die;

class folioController extends JControllerLegacy
{
}