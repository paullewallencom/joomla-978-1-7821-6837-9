===================================================
Packt Publishing - Learning Joomla 3 Extension Development.
                   Chapter 02 source code
                   Getting started with Plugin Development
===================================================

This folder contains the source code for the examples in Chapter 2.

* plg_content_clicktocall_v1.0.0 - initial version of Click-to-call plugin.
  Use plg_content_clicktocall_v1.0.0.zip to install on a Joomla 3 website via extension manager.

* plg_content_clicktocall_v1.1.0 - improve version of Click-to-call plugin that includes parameters.
  Use plg_content_clicktocall_v1.1.0.zip to install on a Joomla 3 website via extension manager.

* plg_content_clicktocall_v1.2.0 - finial version of Click-to-call plugin that includes a language file.
  Use plg_content_clicktocall_v1.2.0.zip to install on a Joomla 3 or Joomla 2.5 website via extension manager.

===================================================
TIM. 14/04/13
===================================================