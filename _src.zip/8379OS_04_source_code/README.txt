===================================================
Packt Publishing - Learning Joomla 3 Extension Development.
                   Chapter 04 source code
                   Getting Started with Component Development
===================================================

This folder contains the source code for the examples in Chapter 4.

* com_folio_v1.0.0 - initial version of Folio component.
  Use com_folio_v1.0.0.zip to install on a Joomla 3 website via extension manager.

===================================================
TIM. 14/04/13
===================================================